"use client"

import { useState } from "react"
import { Barcode, Check, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

// Tipo para o produto
type Product = {
  id: string
  name: string
  price: number
  image: string
  description: string
  barcode: string
}

// Banco de dados simulado de produtos
const productDatabase: Product[] = [
  {
    id: "1",
    name: "Leite Integral",
    price: 4.99,
    image: "/placeholder.svg?height=200&width=200",
    description: "Leite integral 1L",
    barcode: "7891234567890",
  },
  {
    id: "2",
    name: "Pão Francês",
    price: 8.5,
    image: "/placeholder.svg?height=200&width=200",
    description: "Pacote com 5 unidades",
    barcode: "7899876543210",
  },
  {
    id: "3",
    name: "Café em Pó",
    price: 12.9,
    image: "/placeholder.svg?height=200&width=200",
    description: "Café torrado e moído 500g",
    barcode: "7890123456789",
  },
]

export default function ScannerPage() {
  const [barcodeInput, setBarcodeInput] = useState("")
  const [scannedProduct, setScannedProduct] = useState<Product | null>(null)
  const [cartItems, setCartItems] = useState<Product[]>([])
  const [showSuccess, setShowSuccess] = useState(false)

  // Função para buscar produto pelo código de barras
  const handleScan = () => {
    const product = productDatabase.find((p) => p.barcode === barcodeInput)
    setScannedProduct(product || null)
    if (!product) {
      alert("Produto não encontrado!")
    }
  }

  // Função para adicionar ao carrinho
  const addToCart = () => {
    if (scannedProduct) {
      setCartItems([...cartItems, scannedProduct])
      setShowSuccess(true)

      // Esconder mensagem de sucesso após 2 segundos
      setTimeout(() => {
        setShowSuccess(false)
        setScannedProduct(null)
        setBarcodeInput("")
      }, 2000)
    }
  }

  return (
    <div className="container mx-auto max-w-md p-4">
      <h1 className="text-2xl font-bold text-center mb-6">Scanner de Produtos</h1>

      {/* Contador do carrinho */}
      <div className="flex justify-end mb-4">
        <Badge variant="outline" className="flex items-center gap-1 p-2">
          <ShoppingCart className="h-4 w-4" />
          <span>{cartItems.length}</span>
        </Badge>
      </div>

      {/* Área de escaneamento */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Barcode className="h-5 w-5" />
            Escanear Código de Barras
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              type="text"
              placeholder="Digite ou escaneie o código"
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
            />
            <Button onClick={handleScan}>Buscar</Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Teste com os códigos: 7891234567890, 7899876543210, 7890123456789
          </p>
        </CardContent>
      </Card>

      {/* Confirmação do produto */}
      {scannedProduct && (
        <Card className="border-2 border-primary">
          <CardHeader>
            <CardTitle>Confirmar Produto</CardTitle>
          </CardHeader>
          <CardContent className="flex gap-4">
            <div className="w-24 h-24 relative flex-shrink-0">
              <Image
                src={scannedProduct.image || "/placeholder.svg"}
                alt={scannedProduct.name}
                fill
                className="object-contain"
              />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg">{scannedProduct.name}</h3>
              <p className="text-sm text-muted-foreground">{scannedProduct.description}</p>
              <p className="text-lg font-bold mt-2">R$ {scannedProduct.price.toFixed(2)}</p>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" size="lg" onClick={addToCart}>
              Adicionar ao Carrinho
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Mensagem de sucesso */}
      {showSuccess && (
        <div className="fixed inset-0 flex items-center justify-center bg-background/80 z-50">
          <div className="bg-primary text-primary-foreground p-4 rounded-lg flex items-center gap-2 shadow-lg">
            <Check className="h-6 w-6" />
            <span>Produto adicionado ao carrinho!</span>
          </div>
        </div>
      )}
    </div>
  )
}
