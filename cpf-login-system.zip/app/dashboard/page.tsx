import { redirect } from "next/navigation"
import { checkAuth, logout } from "@/lib/actions/auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default async function DashboardPage() {
  const user = await checkAuth()

  // If user is not authenticated, redirect to login page
  if (!user) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between">
          <h1 className="text-xl font-bold">Sistema de Login com CPF</h1>
          <form action={logout}>
            <Button type="submit" variant="outline">
              Sair
            </Button>
          </form>
        </div>
      </header>
      <main className="flex-1 container py-8">
        <Card>
          <CardHeader>
            <CardTitle>Bem-vindo ao Dashboard</CardTitle>
            <CardDescription>Você está logado com sucesso</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p>
                <strong>Nome:</strong> {user.full_name}
              </p>
              <p>
                <strong>CPF:</strong> {user.cpf}
              </p>
              <p>
                <strong>E-mail:</strong> {user.email}
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
      <footer className="border-t py-4">
        <div className="container text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} Sistema de Login com CPF. Todos os direitos reservados.
        </div>
      </footer>
    </div>
  )
}
