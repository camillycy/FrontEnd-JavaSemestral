"use client"

import { useState } from "react"
import Link from "next/link"
import { requestPasswordReset } from "@/lib/actions/auth"
import { InputMask } from "@/components/ui/input-mask"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [debugInfo, setDebugInfo] = useState<any>(null)

  async function handleSubmit(formData: FormData) {
    setIsLoading(true)
    setError(null)
    setSuccess(null)
    setDebugInfo(null)

    try {
      const result = await requestPasswordReset(formData)

      if (result.error) {
        setError(result.error)
      } else {
        setSuccess(result.message || "Um e-mail foi enviado com instruções para redefinir sua senha")

        // For demo purposes only
        if (result.debug) {
          setDebugInfo(result.debug)
        }
      }
    } catch (err) {
      setError("Ocorreu um erro ao solicitar redefinição de senha. Tente novamente.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">Recuperar Senha</CardTitle>
          <CardDescription className="text-center">
            Digite seu CPF para receber um e-mail de recuperação de senha
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {success && (
            <Alert className="mb-4">
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}
          {!success ? (
            <form action={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cpf">CPF</Label>
                <InputMask id="cpf" name="cpf" mask="###.###.###-##" placeholder="000.000.000-00" required />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Enviando..." : "Enviar e-mail de recuperação"}
              </Button>
            </form>
          ) : (
            // For demo purposes only - in production this would not be shown
            debugInfo && (
              <div className="mt-4 p-4 border rounded bg-gray-50">
                <p className="text-sm font-medium">Informações de depuração (apenas para demonstração):</p>
                <p className="text-sm">E-mail: {debugInfo.email}</p>
                <p className="text-sm">Token: {debugInfo.token}</p>
                <Link
                  href={`/reset-password?token=${debugInfo.token}`}
                  className="text-sm text-primary hover:underline"
                >
                  Link para redefinir senha
                </Link>
              </div>
            )
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/login" className="text-sm text-primary hover:underline">
            Voltar para o login
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
