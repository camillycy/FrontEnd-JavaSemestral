"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Input } from "@/components/ui/input"

interface InputMaskProps extends React.InputHTMLAttributes<HTMLInputElement> {
  mask: string
  value?: string
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export function InputMask({ mask, value, onChange, ...props }: InputMaskProps) {
  const [inputValue, setInputValue] = useState(value || "")
  const inputRef = useRef<HTMLInputElement>(null)

  // Apply mask to value
  const applyMask = (value: string) => {
    let maskedValue = ""
    let valueIndex = 0

    for (let i = 0; i < mask.length && valueIndex < value.length; i++) {
      const maskChar = mask[i]
      const valueChar = value[valueIndex]

      if (maskChar === "#") {
        if (/\d/.test(valueChar)) {
          maskedValue += valueChar
          valueIndex++
        } else {
          valueIndex++
          i--
        }
      } else if (maskChar === "A") {
        if (/[a-zA-Z]/.test(valueChar)) {
          maskedValue += valueChar
          valueIndex++
        } else {
          valueIndex++
          i--
        }
      } else if (maskChar === "S") {
        if (/[a-zA-Z0-9]/.test(valueChar)) {
          maskedValue += valueChar
          valueIndex++
        } else {
          valueIndex++
          i--
        }
      } else {
        maskedValue += maskChar
        if (valueChar === maskChar) {
          valueIndex++
        }
      }
    }

    return maskedValue
  }

  // Remove mask from value
  const removeMask = (value: string) => {
    return value.replace(/[^\d]/g, "")
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = removeMask(e.target.value)
    const newMaskedValue = applyMask(rawValue)

    setInputValue(newMaskedValue)

    // Create a synthetic event to pass to the parent component
    if (onChange) {
      const syntheticEvent = {
        ...e,
        target: {
          ...e.target,
          value: newMaskedValue,
        },
      }
      onChange(syntheticEvent)
    }
  }

  // Update input value when prop value changes
  useEffect(() => {
    if (value !== undefined && value !== inputValue) {
      setInputValue(value)
    }
  }, [value])

  return <Input ref={inputRef} value={inputValue} onChange={handleChange} {...props} />
}
