"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { createActionClient } from "@/lib/supabase/server"
import { validateCPF, formatCPF } from "@/lib/utils/cpf"
import { hashPassword, verifyPassword } from "@/lib/utils/password"
import crypto from "crypto"

// Login action
export async function login(formData: FormData) {
  const cpf = formData.get("cpf") as string
  const password = formData.get("password") as string

  // Validate CPF format
  if (!validateCPF(cpf)) {
    return { error: "CPF inválido" }
  }

  const formattedCPF = formatCPF(cpf)

  try {
    const supabase = createActionClient()

    // Get user by CPF
    const { data: user, error: userError } = await supabase.from("users").select("*").eq("cpf", formattedCPF).single()

    if (userError || !user) {
      return { error: "Usuário não encontrado" }
    }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password_hash)

    if (!isValidPassword) {
      return { error: "Senha incorreta" }
    }

    // Set session cookie (in a real app, you would use JWT or similar)
    cookies().set("user_id", user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: "/",
    })

    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    return { error: "Erro ao fazer login" }
  }
}

// Register action
export async function register(formData: FormData) {
  const cpf = formData.get("cpf") as string
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const fullName = formData.get("fullName") as string

  // Validate CPF format
  if (!validateCPF(cpf)) {
    return { error: "CPF inválido" }
  }

  const formattedCPF = formatCPF(cpf)

  try {
    const supabase = createActionClient()

    // Check if user already exists
    const { data: existingUser } = await supabase
      .from("users")
      .select("id")
      .or(`cpf.eq.${formattedCPF},email.eq.${email}`)
      .single()

    if (existingUser) {
      return { error: "CPF ou e-mail já cadastrado" }
    }

    // Hash password
    const passwordHash = await hashPassword(password)

    // Insert new user
    const { data: newUser, error: insertError } = await supabase
      .from("users")
      .insert({
        cpf: formattedCPF,
        email,
        password_hash: passwordHash,
        full_name: fullName,
      })
      .select()
      .single()

    if (insertError) {
      console.error("Registration error:", insertError)
      return { error: "Erro ao cadastrar usuário" }
    }

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    return { error: "Erro ao cadastrar usuário" }
  }
}

// Request password reset action
export async function requestPasswordReset(formData: FormData) {
  const cpf = formData.get("cpf") as string

  // Validate CPF format
  if (!validateCPF(cpf)) {
    return { error: "CPF inválido" }
  }

  const formattedCPF = formatCPF(cpf)

  try {
    const supabase = createActionClient()

    // Get user by CPF
    const { data: user, error: userError } = await supabase.from("users").select("*").eq("cpf", formattedCPF).single()

    if (userError || !user) {
      return { error: "Usuário não encontrado" }
    }

    // Generate reset token
    const token = crypto.randomBytes(32).toString("hex")
    const expiresAt = new Date()
    expiresAt.setHours(expiresAt.getHours() + 1) // Token expires in 1 hour

    // Save token to database
    const { error: tokenError } = await supabase.from("password_reset_tokens").insert({
      user_id: user.id,
      token,
      expires_at: expiresAt.toISOString(),
    })

    if (tokenError) {
      console.error("Token creation error:", tokenError)
      return { error: "Erro ao gerar token de recuperação" }
    }

    // In a real application, you would send an email with the reset link
    // For this example, we'll just return the token
    console.log(`Reset token for ${user.email}: ${token}`)

    return {
      success: true,
      message: "Um e-mail foi enviado com instruções para redefinir sua senha",
      // Only for demo purposes, in production this should not be returned to the client
      debug: { email: user.email, token },
    }
  } catch (error) {
    console.error("Password reset request error:", error)
    return { error: "Erro ao solicitar redefinição de senha" }
  }
}

// Reset password action
export async function resetPassword(formData: FormData) {
  const token = formData.get("token") as string
  const password = formData.get("password") as string

  try {
    const supabase = createActionClient()

    // Get token from database
    const { data: tokenData, error: tokenError } = await supabase
      .from("password_reset_tokens")
      .select("*")
      .eq("token", token)
      .eq("used", false)
      .single()

    if (tokenError || !tokenData) {
      return { error: "Token inválido ou expirado" }
    }

    // Check if token is expired
    if (new Date(tokenData.expires_at) < new Date()) {
      return { error: "Token expirado" }
    }

    // Hash new password
    const passwordHash = await hashPassword(password)

    // Update user password
    const { error: updateError } = await supabase
      .from("users")
      .update({ password_hash: passwordHash })
      .eq("id", tokenData.user_id)

    if (updateError) {
      console.error("Password update error:", updateError)
      return { error: "Erro ao atualizar senha" }
    }

    // Mark token as used
    await supabase.from("password_reset_tokens").update({ used: true }).eq("id", tokenData.id)

    return { success: true }
  } catch (error) {
    console.error("Password reset error:", error)
    return { error: "Erro ao redefinir senha" }
  }
}

// Check if user is authenticated
export async function checkAuth() {
  const userId = cookies().get("user_id")?.value

  if (!userId) {
    return null
  }

  try {
    const supabase = createActionClient()

    const { data: user, error } = await supabase
      .from("users")
      .select("id, cpf, email, full_name")
      .eq("id", userId)
      .single()

    if (error || !user) {
      cookies().delete("user_id")
      return null
    }

    return user
  } catch (error) {
    console.error("Auth check error:", error)
    cookies().delete("user_id")
    return null
  }
}

// Logout action
export async function logout() {
  cookies().delete("user_id")
  redirect("/login")
}
