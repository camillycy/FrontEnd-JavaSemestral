import { createServerComponentClient, createServerActionClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import type { Database } from "@/lib/supabase/database.types"

// Create a server-side supabase client
export const createServerClient = () => {
  return createServerComponentClient<Database>({ cookies })
}

// Create a server action supabase client
export const createActionClient = () => {
  return createServerActionClient<Database>({ cookies })
}
